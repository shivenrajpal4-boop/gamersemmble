import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const listGames = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db
      .query("games")
      .filter((q) => q.eq(q.field("isActive"), true))
      .collect();
  },
});

export const getGamesByCategory = query({
  args: { category: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("games")
      .withIndex("by_category", (q) => q.eq("category", args.category))
      .filter((q) => q.eq(q.field("isActive"), true))
      .collect();
  },
});

export const getGame = query({
  args: { gameId: v.id("games") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.gameId);
  },
});

export const saveScore = mutation({
  args: {
    gameId: v.id("games"),
    score: v.number(),
    playerName: v.string(),
    gameData: v.optional(v.object({
      level: v.optional(v.number()),
      time: v.optional(v.number()),
      moves: v.optional(v.number()),
    })),
  },
  handler: async (ctx, args) => {
    const userId = await ctx.auth.getUserIdentity();
    
    await ctx.db.insert("scores", {
      userId: userId?.subject,
      gameId: args.gameId,
      score: args.score,
      playerName: args.playerName,
      gameData: args.gameData,
    });

    // Update play count
    const game = await ctx.db.get(args.gameId);
    if (game) {
      await ctx.db.patch(args.gameId, {
        playCount: game.playCount + 1,
      });
    }
  },
});

export const getLeaderboard = query({
  args: { gameId: v.id("games"), limit: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const limit = args.limit || 10;
    return await ctx.db
      .query("scores")
      .withIndex("by_game", (q) => q.eq("gameId", args.gameId))
      .order("desc")
      .take(limit);
  },
});

export const initializeGames = mutation({
  args: {},
  handler: async (ctx) => {
    const existingGames = await ctx.db.query("games").collect();
    if (existingGames.length > 0) return;

    const games = [
      {
        name: "Snake 3D",
        description: "Classic snake game with a 3D twist",
        category: "arcade",
        difficulty: "easy",
        playCount: 0,
        rating: 4.5,
        isActive: true,
      },
      {
        name: "Memory Matrix",
        description: "Test your memory with colorful patterns",
        category: "puzzle",
        difficulty: "medium",
        playCount: 0,
        rating: 4.2,
        isActive: true,
      },
      {
        name: "Cosmic Tetris",
        description: "Tetris in space with stunning visuals",
        category: "arcade",
        difficulty: "medium",
        playCount: 0,
        rating: 4.7,
        isActive: true,
      },
      {
        name: "Color Rush",
        description: "Match colors as fast as you can",
        category: "reflex",
        difficulty: "easy",
        playCount: 0,
        rating: 4.0,
        isActive: true,
      },
      {
        name: "Maze Runner 3D",
        description: "Navigate through complex 3D mazes",
        category: "adventure",
        difficulty: "hard",
        playCount: 0,
        rating: 4.3,
        isActive: true,
      },
      {
        name: "Number Crunch",
        description: "Quick math challenges to boost your brain",
        category: "educational",
        difficulty: "medium",
        playCount: 0,
        rating: 3.9,
        isActive: true,
      },
    ];

    for (const game of games) {
      await ctx.db.insert("games", game);
    }
  },
});
