import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  games: defineTable({
    name: v.string(),
    description: v.string(),
    category: v.string(),
    difficulty: v.string(),
    playCount: v.number(),
    rating: v.number(),
    isActive: v.boolean(),
  }).index("by_category", ["category"]),
  
  scores: defineTable({
    userId: v.optional(v.id("users")),
    gameId: v.id("games"),
    score: v.number(),
    playerName: v.string(),
    gameData: v.optional(v.object({
      level: v.optional(v.number()),
      time: v.optional(v.number()),
      moves: v.optional(v.number()),
    })),
  }).index("by_game", ["gameId"])
    .index("by_user", ["userId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
