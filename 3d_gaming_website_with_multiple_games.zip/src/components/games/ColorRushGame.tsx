import { useState, useEffect, useCallback } from 'react';
import { useMutation } from 'convex/react';
import { api } from '../../../convex/_generated/api';

interface ColorRushGameProps {
  gameId: string;
}

export default function ColorRushGame({ gameId }: ColorRushGameProps) {
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [gameStarted, setGameStarted] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [playerName, setPlayerName] = useState('');
  const [targetColor, setTargetColor] = useState('');
  const [options, setOptions] = useState<string[]>([]);
  const [streak, setStreak] = useState(0);
  const saveScore = useMutation(api.games.saveScore);

  const colors = [
    { name: 'Red', value: '#ff6b6b' },
    { name: 'Blue', value: '#4ecdc4' },
    { name: 'Green', value: '#45b7d1' },
    { name: 'Yellow', value: '#ffeaa7' },
    { name: 'Purple', value: '#dda0dd' },
    { name: 'Orange', value: '#ff9f43' },
    { name: 'Pink', value: '#ff9ff3' },
    { name: 'Cyan', value: '#54a0ff' },
  ];

  const generateRound = useCallback(() => {
    const shuffled = [...colors].sort(() => Math.random() - 0.5);
    const target = shuffled[0];
    const wrongOptions = shuffled.slice(1, 4);
    const allOptions = [target, ...wrongOptions].sort(() => Math.random() - 0.5);
    
    setTargetColor(target.name);
    setOptions(allOptions.map(c => c.name));
  }, []);

  const startGame = () => {
    if (playerName.trim()) {
      setGameStarted(true);
      setScore(0);
      setTimeLeft(30);
      setGameOver(false);
      setStreak(0);
      generateRound();
    }
  };

  const handleColorClick = async (selectedColor: string) => {
    if (!gameStarted || gameOver) return;

    if (selectedColor === targetColor) {
      const points = 10 + streak * 2;
      setScore(prev => prev + points);
      setStreak(prev => prev + 1);
      generateRound();
    } else {
      setStreak(0);
      // Small penalty for wrong answer
      setScore(prev => Math.max(0, prev - 5));
    }
  };

  const endGame = useCallback(async () => {
    setGameOver(true);
    setGameStarted(false);
    
    if (score > 0 && playerName.trim()) {
      try {
        await saveScore({
          gameId: gameId as any,
          score,
          playerName: playerName.trim(),
          gameData: { time: 30 - timeLeft },
        });
      } catch (error) {
        console.error('Failed to save score:', error);
      }
    }
  }, [score, playerName, timeLeft, saveScore, gameId]);

  useEffect(() => {
    if (!gameStarted || gameOver) return;

    if (timeLeft <= 0) {
      endGame();
      return;
    }

    const timer = setTimeout(() => {
      setTimeLeft(prev => prev - 1);
    }, 1000);

    return () => clearTimeout(timer);
  }, [timeLeft, gameStarted, gameOver, endGame]);

  const resetGame = () => {
    setGameStarted(false);
    setGameOver(false);
    setScore(0);
    setTimeLeft(30);
    setStreak(0);
  };

  const getColorValue = (colorName: string) => {
    return colors.find(c => c.name === colorName)?.value || '#000';
  };

  if (!gameStarted && !gameOver) {
    return (
      <div className="flex flex-col items-center space-y-6 bg-black/50 backdrop-blur-md rounded-2xl p-8 border border-white/20">
        <h2 className="text-3xl font-bold text-white mb-4">Color Rush</h2>
        <div className="space-y-4">
          <input
            type="text"
            placeholder="Enter your name"
            value={playerName}
            onChange={(e) => setPlayerName(e.target.value)}
            className="px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:border-cyan-400"
          />
          <button
            onClick={startGame}
            disabled={!playerName.trim()}
            className="w-full px-6 py-3 bg-gradient-to-r from-cyan-500 to-purple-600 rounded-lg text-white font-bold hover:scale-105 transition-transform disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Start Game
          </button>
        </div>
        <div className="text-white/70 text-center">
          <p>Click the color that matches the name shown</p>
          <p>You have 30 seconds to score as many points as possible!</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center space-y-6 max-w-2xl mx-auto">
      <div className="flex items-center justify-between w-full text-white bg-black/30 backdrop-blur-md rounded-xl p-4 border border-white/20">
        <div className="text-xl">Score: <span className="text-cyan-400 font-bold">{score}</span></div>
        <div className="text-xl">Time: <span className="text-red-400 font-bold">{timeLeft}s</span></div>
        <div className="text-xl">Streak: <span className="text-purple-400 font-bold">{streak}</span></div>
      </div>

      {gameStarted && !gameOver && (
        <div className="text-center bg-black/50 backdrop-blur-md rounded-2xl p-8 border border-white/20">
          <h3 className="text-2xl text-white mb-2">Click the color:</h3>
          <div 
            className="text-6xl font-bold mb-8 animate-pulse"
            style={{ color: getColorValue(targetColor) }}
          >
            {targetColor}
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            {options.map((colorName, index) => (
              <button
                key={index}
                onClick={() => handleColorClick(colorName)}
                className="w-32 h-32 rounded-2xl transition-all duration-200 transform hover:scale-110 hover:shadow-2xl border-4 border-white/20 hover:border-white/60"
                style={{ 
                  backgroundColor: getColorValue(colorName),
                  boxShadow: `0 8px 25px ${getColorValue(colorName)}40`
                }}
              />
            ))}
          </div>
        </div>
      )}

      {gameOver && (
        <div className="bg-black/80 backdrop-blur-md rounded-2xl p-8 border border-red-500/50 text-center">
          <h3 className="text-3xl font-bold text-white mb-4">Time's Up!</h3>
          <p className="text-xl text-cyan-400 mb-2">Final Score: {score}</p>
          <p className="text-lg text-purple-400 mb-2">Best Streak: {streak}</p>
          <p className="text-lg text-yellow-400 mb-6">Player: {playerName}</p>
          <button
            onClick={resetGame}
            className="px-6 py-3 bg-gradient-to-r from-purple-600 to-cyan-600 rounded-lg text-white font-bold hover:scale-105 transition-transform"
          >
            Play Again
          </button>
        </div>
      )}
    </div>
  );
}
