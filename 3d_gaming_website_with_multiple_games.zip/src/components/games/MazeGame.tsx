import { useState, useEffect, useCallback, useRef } from 'react';
import { useMutation } from 'convex/react';
import { api } from '../../../convex/_generated/api';

interface MazeGameProps {
  gameId: string;
}

type Cell = 0 | 1 | 2 | 3; // 0: wall, 1: path, 2: player, 3: goal

export default function MazeGame({ gameId }: MazeGameProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [maze, setMaze] = useState<Cell[][]>([]);
  const [playerPos, setPlayerPos] = useState({ x: 1, y: 1 });
  const [goalPos, setGoalPos] = useState({ x: 0, y: 0 });
  const [gameStarted, setGameStarted] = useState(false);
  const [gameWon, setGameWon] = useState(false);
  const [playerName, setPlayerName] = useState('');
  const [moves, setMoves] = useState(0);
  const [startTime, setStartTime] = useState(0);
  const [level, setLevel] = useState(1);
  const saveScore = useMutation(api.games.saveScore);

  const CELL_SIZE = 20;
  const MAZE_SIZE = 15 + level * 2; // Maze gets bigger with each level

  const generateMaze = useCallback(() => {
    const size = MAZE_SIZE;
    const newMaze: Cell[][] = Array(size).fill(null).map(() => Array(size).fill(0));
    
    // Simple maze generation using recursive backtracking
    const stack: Array<{x: number, y: number}> = [];
    const visited: boolean[][] = Array(size).fill(null).map(() => Array(size).fill(false));
    
    const isValid = (x: number, y: number) => {
      return x >= 0 && x < size && y >= 0 && y < size;
    };
    
    const getNeighbors = (x: number, y: number) => {
      const neighbors = [];
      const directions = [[0, 2], [2, 0], [0, -2], [-2, 0]];
      
      for (const [dx, dy] of directions) {
        const nx = x + dx;
        const ny = y + dy;
        if (isValid(nx, ny) && !visited[ny][nx]) {
          neighbors.push({ x: nx, y: ny });
        }
      }
      return neighbors;
    };
    
    // Start from (1, 1)
    let currentX = 1;
    let currentY = 1;
    visited[currentY][currentX] = true;
    newMaze[currentY][currentX] = 1;
    
    while (true) {
      const neighbors = getNeighbors(currentX, currentY);
      
      if (neighbors.length > 0) {
        const next = neighbors[Math.floor(Math.random() * neighbors.length)];
        
        // Remove wall between current and next
        const wallX = currentX + (next.x - currentX) / 2;
        const wallY = currentY + (next.y - currentY) / 2;
        newMaze[wallY][wallX] = 1;
        newMaze[next.y][next.x] = 1;
        
        visited[next.y][next.x] = true;
        stack.push({ x: currentX, y: currentY });
        currentX = next.x;
        currentY = next.y;
      } else if (stack.length > 0) {
        const prev = stack.pop()!;
        currentX = prev.x;
        currentY = prev.y;
      } else {
        break;
      }
    }
    
    // Set goal at bottom-right corner
    const goalX = size - 2;
    const goalY = size - 2;
    newMaze[goalY][goalX] = 1;
    
    setMaze(newMaze);
    setPlayerPos({ x: 1, y: 1 });
    setGoalPos({ x: goalX, y: goalY });
    setMoves(0);
  }, [MAZE_SIZE, level]);

  const startGame = () => {
    if (playerName.trim()) {
      setGameStarted(true);
      setGameWon(false);
      setStartTime(Date.now());
      setLevel(1);
      generateMaze();
    }
  };

  const nextLevel = () => {
    setLevel(prev => prev + 1);
    setGameWon(false);
    generateMaze();
  };

  const movePlayer = useCallback((dx: number, dy: number) => {
    if (!gameStarted || gameWon) return;

    const newX = playerPos.x + dx;
    const newY = playerPos.y + dy;

    // Check bounds and walls
    if (newX >= 0 && newX < MAZE_SIZE && newY >= 0 && newY < MAZE_SIZE && maze[newY][newX] !== 0) {
      setPlayerPos({ x: newX, y: newY });
      setMoves(prev => prev + 1);

      // Check if reached goal
      if (newX === goalPos.x && newY === goalPos.y) {
        setGameWon(true);
        const timeElapsed = Math.floor((Date.now() - startTime) / 1000);
        const score = Math.max(1000 - moves * 10 - timeElapsed * 5, 100) * level;
        
        if (playerName.trim()) {
          saveScore({
            gameId: gameId as any,
            score,
            playerName: playerName.trim(),
            gameData: { level, time: timeElapsed, moves },
          });
        }
      }
    }
  }, [gameStarted, gameWon, playerPos, MAZE_SIZE, maze, goalPos, startTime, moves, level, playerName, saveScore, gameId]);

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      switch (e.key) {
        case 'ArrowUp':
          movePlayer(0, -1);
          break;
        case 'ArrowDown':
          movePlayer(0, 1);
          break;
        case 'ArrowLeft':
          movePlayer(-1, 0);
          break;
        case 'ArrowRight':
          movePlayer(1, 0);
          break;
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [movePlayer]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || maze.length === 0) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = MAZE_SIZE * CELL_SIZE;
    canvas.height = MAZE_SIZE * CELL_SIZE;

    // Clear canvas
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw maze
    for (let y = 0; y < MAZE_SIZE; y++) {
      for (let x = 0; x < MAZE_SIZE; x++) {
        if (maze[y][x] === 1) {
          ctx.fillStyle = '#333';
          ctx.fillRect(x * CELL_SIZE, y * CELL_SIZE, CELL_SIZE, CELL_SIZE);
        }
      }
    }

    // Draw goal
    ctx.fillStyle = '#00ff00';
    ctx.fillRect(goalPos.x * CELL_SIZE + 2, goalPos.y * CELL_SIZE + 2, CELL_SIZE - 4, CELL_SIZE - 4);

    // Draw player
    ctx.fillStyle = '#00ffff';
    ctx.fillRect(playerPos.x * CELL_SIZE + 2, playerPos.y * CELL_SIZE + 2, CELL_SIZE - 4, CELL_SIZE - 4);

    // Draw grid
    ctx.strokeStyle = '#555';
    ctx.lineWidth = 1;
    for (let i = 0; i <= MAZE_SIZE; i++) {
      ctx.beginPath();
      ctx.moveTo(i * CELL_SIZE, 0);
      ctx.lineTo(i * CELL_SIZE, MAZE_SIZE * CELL_SIZE);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, i * CELL_SIZE);
      ctx.lineTo(MAZE_SIZE * CELL_SIZE, i * CELL_SIZE);
      ctx.stroke();
    }
  }, [maze, playerPos, goalPos, MAZE_SIZE]);

  const resetGame = () => {
    setGameStarted(false);
    setGameWon(false);
    setLevel(1);
    setMoves(0);
  };

  if (!gameStarted) {
    return (
      <div className="flex flex-col items-center space-y-6 bg-black/50 backdrop-blur-md rounded-2xl p-8 border border-white/20">
        <h2 className="text-3xl font-bold text-white mb-4">Maze Runner 3D</h2>
        <div className="space-y-4">
          <input
            type="text"
            placeholder="Enter your name"
            value={playerName}
            onChange={(e) => setPlayerName(e.target.value)}
            className="px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:border-cyan-400"
          />
          <button
            onClick={startGame}
            disabled={!playerName.trim()}
            className="w-full px-6 py-3 bg-gradient-to-r from-cyan-500 to-purple-600 rounded-lg text-white font-bold hover:scale-105 transition-transform disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Start Game
          </button>
        </div>
        <div className="text-white/70 text-center">
          <p>Use arrow keys to navigate through the maze</p>
          <p>Reach the green goal to advance to the next level!</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center space-y-6">
      <div className="flex items-center space-x-8 text-white">
        <div className="text-xl">Level: <span className="text-cyan-400 font-bold">{level}</span></div>
        <div className="text-xl">Moves: <span className="text-purple-400 font-bold">{moves}</span></div>
        <div className="text-xl">Player: <span className="text-pink-400 font-bold">{playerName}</span></div>
      </div>

      <div className="relative">
        <canvas
          ref={canvasRef}
          className="border-2 border-cyan-400 rounded-lg shadow-2xl shadow-cyan-400/20"
        />
        
        {gameWon && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center rounded-lg">
            <h3 className="text-3xl font-bold text-white mb-4">Level Complete!</h3>
            <p className="text-xl text-cyan-400 mb-2">Moves: {moves}</p>
            <p className="text-xl text-purple-400 mb-6">Time: {Math.floor((Date.now() - startTime) / 1000)}s</p>
            <div className="space-x-4">
              <button
                onClick={nextLevel}
                className="px-6 py-3 bg-gradient-to-r from-green-600 to-cyan-600 rounded-lg text-white font-bold hover:scale-105 transition-transform"
              >
                Next Level
              </button>
              <button
                onClick={resetGame}
                className="px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg text-white font-bold hover:scale-105 transition-transform"
              >
                Restart
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="text-white/70 text-center">
        <p>🔵 You • 🟢 Goal • Use arrow keys to move</p>
        <p>Find the shortest path to maximize your score!</p>
      </div>
    </div>
  );
}
