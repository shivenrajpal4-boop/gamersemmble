import { useState, useEffect, useCallback, useRef } from 'react';
import { useMutation } from 'convex/react';
import { api } from '../../../convex/_generated/api';

interface TetrisGameProps {
  gameId: string;
}

type TetrominoType = 'I' | 'O' | 'T' | 'S' | 'Z' | 'J' | 'L';
type Board = number[][];

const BOARD_WIDTH = 10;
const BOARD_HEIGHT = 20;
const CELL_SIZE = 25;

const TETROMINOES: Record<TetrominoType, number[][]> = {
  I: [[1, 1, 1, 1]],
  O: [[1, 1], [1, 1]],
  T: [[0, 1, 0], [1, 1, 1]],
  S: [[0, 1, 1], [1, 1, 0]],
  Z: [[1, 1, 0], [0, 1, 1]],
  J: [[1, 0, 0], [1, 1, 1]],
  L: [[0, 0, 1], [1, 1, 1]],
};

const COLORS = ['#000', '#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4', '#ffeaa7', '#dda0dd', '#ff9ff3'];

export default function TetrisGame({ gameId }: TetrisGameProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [board, setBoard] = useState<Board>(() => 
    Array(BOARD_HEIGHT).fill(null).map(() => Array(BOARD_WIDTH).fill(0))
  );
  const [currentPiece, setCurrentPiece] = useState<{
    shape: number[][];
    x: number;
    y: number;
    type: TetrominoType;
  } | null>(null);
  const [score, setScore] = useState(0);
  const [lines, setLines] = useState(0);
  const [level, setLevel] = useState(1);
  const [gameOver, setGameOver] = useState(false);
  const [gameStarted, setGameStarted] = useState(false);
  const [playerName, setPlayerName] = useState('');
  const [dropTime, setDropTime] = useState(1000);
  const saveScore = useMutation(api.games.saveScore);

  const createRandomPiece = useCallback((): {
    shape: number[][];
    x: number;
    y: number;
    type: TetrominoType;
  } => {
    const types: TetrominoType[] = ['I', 'O', 'T', 'S', 'Z', 'J', 'L'];
    const type = types[Math.floor(Math.random() * types.length)];
    const shape = TETROMINOES[type];
    return {
      shape,
      x: Math.floor(BOARD_WIDTH / 2) - Math.floor(shape[0].length / 2),
      y: 0,
      type,
    };
  }, []);

  const isValidMove = useCallback((piece: typeof currentPiece, newX: number, newY: number, newShape?: number[][]) => {
    if (!piece) return false;
    const shape = newShape || piece.shape;
    
    for (let y = 0; y < shape.length; y++) {
      for (let x = 0; x < shape[y].length; x++) {
        if (shape[y][x]) {
          const boardX = newX + x;
          const boardY = newY + y;
          
          if (boardX < 0 || boardX >= BOARD_WIDTH || boardY >= BOARD_HEIGHT) {
            return false;
          }
          
          if (boardY >= 0 && board[boardY][boardX]) {
            return false;
          }
        }
      }
    }
    return true;
  }, [board]);

  const rotatePiece = useCallback((shape: number[][]) => {
    const rotated = shape[0].map((_, index) =>
      shape.map(row => row[index]).reverse()
    );
    return rotated;
  }, []);

  const placePiece = useCallback(() => {
    if (!currentPiece) return;

    const newBoard = board.map(row => [...row]);
    const colorIndex = Object.keys(TETROMINOES).indexOf(currentPiece.type) + 1;

    for (let y = 0; y < currentPiece.shape.length; y++) {
      for (let x = 0; x < currentPiece.shape[y].length; x++) {
        if (currentPiece.shape[y][x]) {
          const boardY = currentPiece.y + y;
          const boardX = currentPiece.x + x;
          if (boardY >= 0) {
            newBoard[boardY][boardX] = colorIndex;
          }
        }
      }
    }

    // Check for completed lines
    const completedLines: number[] = [];
    for (let y = 0; y < BOARD_HEIGHT; y++) {
      if (newBoard[y].every(cell => cell !== 0)) {
        completedLines.push(y);
      }
    }

    // Remove completed lines
    completedLines.forEach(lineIndex => {
      newBoard.splice(lineIndex, 1);
      newBoard.unshift(Array(BOARD_WIDTH).fill(0));
    });

    // Update score and lines
    if (completedLines.length > 0) {
      const points = [0, 100, 300, 500, 800][completedLines.length] * level;
      setScore(prev => prev + points);
      setLines(prev => prev + completedLines.length);
      
      // Increase level every 10 lines
      const newLines = lines + completedLines.length;
      const newLevel = Math.floor(newLines / 10) + 1;
      if (newLevel > level) {
        setLevel(newLevel);
        setDropTime(Math.max(100, 1000 - (newLevel - 1) * 100));
      }
    }

    setBoard(newBoard);

    // Check game over
    const newPiece = createRandomPiece();
    if (!isValidMove(newPiece, newPiece.x, newPiece.y)) {
      setGameOver(true);
      if (score > 0 && playerName.trim()) {
        saveScore({
          gameId: gameId as any,
          score,
          playerName: playerName.trim(),
          gameData: { level, time: Date.now() },
        });
      }
    } else {
      setCurrentPiece(newPiece);
    }
  }, [currentPiece, board, level, lines, score, playerName, createRandomPiece, isValidMove, saveScore, gameId]);

  const movePiece = useCallback((dx: number, dy: number) => {
    if (!currentPiece || gameOver) return;

    const newX = currentPiece.x + dx;
    const newY = currentPiece.y + dy;

    if (isValidMove(currentPiece, newX, newY)) {
      setCurrentPiece(prev => prev ? { ...prev, x: newX, y: newY } : null);
    } else if (dy > 0) {
      // Piece hit bottom, place it
      placePiece();
    }
  }, [currentPiece, gameOver, isValidMove, placePiece]);

  const rotatePieceHandler = useCallback(() => {
    if (!currentPiece || gameOver) return;

    const rotatedShape = rotatePiece(currentPiece.shape);
    if (isValidMove(currentPiece, currentPiece.x, currentPiece.y, rotatedShape)) {
      setCurrentPiece(prev => prev ? { ...prev, shape: rotatedShape } : null);
    }
  }, [currentPiece, gameOver, rotatePiece, isValidMove]);

  const startGame = () => {
    if (playerName.trim()) {
      setGameStarted(true);
      setBoard(Array(BOARD_HEIGHT).fill(null).map(() => Array(BOARD_WIDTH).fill(0)));
      setCurrentPiece(createRandomPiece());
      setScore(0);
      setLines(0);
      setLevel(1);
      setDropTime(1000);
      setGameOver(false);
    }
  };

  const resetGame = () => {
    setGameStarted(false);
    setCurrentPiece(null);
  };

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (!gameStarted || gameOver) return;

      switch (e.key) {
        case 'ArrowLeft':
          movePiece(-1, 0);
          break;
        case 'ArrowRight':
          movePiece(1, 0);
          break;
        case 'ArrowDown':
          movePiece(0, 1);
          break;
        case 'ArrowUp':
        case ' ':
          rotatePieceHandler();
          break;
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [gameStarted, gameOver, movePiece, rotatePieceHandler]);

  useEffect(() => {
    if (!gameStarted || gameOver) return;

    const interval = setInterval(() => {
      movePiece(0, 1);
    }, dropTime);

    return () => clearInterval(interval);
  }, [gameStarted, gameOver, dropTime, movePiece]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw board
    for (let y = 0; y < BOARD_HEIGHT; y++) {
      for (let x = 0; x < BOARD_WIDTH; x++) {
        if (board[y][x]) {
          ctx.fillStyle = COLORS[board[y][x]];
          ctx.fillRect(x * CELL_SIZE, y * CELL_SIZE, CELL_SIZE - 1, CELL_SIZE - 1);
        }
      }
    }

    // Draw current piece
    if (currentPiece) {
      const colorIndex = Object.keys(TETROMINOES).indexOf(currentPiece.type) + 1;
      ctx.fillStyle = COLORS[colorIndex];
      
      for (let y = 0; y < currentPiece.shape.length; y++) {
        for (let x = 0; x < currentPiece.shape[y].length; x++) {
          if (currentPiece.shape[y][x]) {
            const drawX = (currentPiece.x + x) * CELL_SIZE;
            const drawY = (currentPiece.y + y) * CELL_SIZE;
            ctx.fillRect(drawX, drawY, CELL_SIZE - 1, CELL_SIZE - 1);
          }
        }
      }
    }

    // Draw grid
    ctx.strokeStyle = '#333';
    ctx.lineWidth = 1;
    for (let x = 0; x <= BOARD_WIDTH; x++) {
      ctx.beginPath();
      ctx.moveTo(x * CELL_SIZE, 0);
      ctx.lineTo(x * CELL_SIZE, BOARD_HEIGHT * CELL_SIZE);
      ctx.stroke();
    }
    for (let y = 0; y <= BOARD_HEIGHT; y++) {
      ctx.beginPath();
      ctx.moveTo(0, y * CELL_SIZE);
      ctx.lineTo(BOARD_WIDTH * CELL_SIZE, y * CELL_SIZE);
      ctx.stroke();
    }
  }, [board, currentPiece]);

  if (!gameStarted) {
    return (
      <div className="flex flex-col items-center space-y-6 bg-black/50 backdrop-blur-md rounded-2xl p-8 border border-white/20">
        <h2 className="text-3xl font-bold text-white mb-4">Cosmic Tetris</h2>
        <div className="space-y-4">
          <input
            type="text"
            placeholder="Enter your name"
            value={playerName}
            onChange={(e) => setPlayerName(e.target.value)}
            className="px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:border-cyan-400"
          />
          <button
            onClick={startGame}
            disabled={!playerName.trim()}
            className="w-full px-6 py-3 bg-gradient-to-r from-cyan-500 to-purple-600 rounded-lg text-white font-bold hover:scale-105 transition-transform disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Start Game
          </button>
        </div>
        <div className="text-white/70 text-center">
          <p>Arrow keys to move, Up/Space to rotate</p>
          <p>Complete lines to score points!</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col lg:flex-row items-start space-y-6 lg:space-y-0 lg:space-x-8">
      <div className="flex flex-col items-center space-y-4">
        <canvas
          ref={canvasRef}
          width={BOARD_WIDTH * CELL_SIZE}
          height={BOARD_HEIGHT * CELL_SIZE}
          className="border-2 border-cyan-400 rounded-lg shadow-2xl shadow-cyan-400/20"
        />
        
        {gameOver && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center rounded-lg">
            <h3 className="text-3xl font-bold text-white mb-4">Game Over!</h3>
            <p className="text-xl text-cyan-400 mb-6">Final Score: {score}</p>
            <button
              onClick={resetGame}
              className="px-6 py-3 bg-gradient-to-r from-purple-600 to-cyan-600 rounded-lg text-white font-bold hover:scale-105 transition-transform"
            >
              Play Again
            </button>
          </div>
        )}
      </div>

      <div className="bg-black/30 backdrop-blur-md rounded-2xl p-6 border border-white/20 min-w-48">
        <h3 className="text-xl font-bold text-white mb-4">Game Stats</h3>
        <div className="space-y-3 text-white">
          <div>Score: <span className="text-cyan-400 font-bold">{score}</span></div>
          <div>Lines: <span className="text-purple-400 font-bold">{lines}</span></div>
          <div>Level: <span className="text-pink-400 font-bold">{level}</span></div>
          <div>Player: <span className="text-yellow-400 font-bold">{playerName}</span></div>
        </div>
        
        <div className="mt-6 text-white/70 text-sm">
          <p>Controls:</p>
          <p>← → Move</p>
          <p>↓ Soft drop</p>
          <p>↑ / Space Rotate</p>
        </div>
      </div>
    </div>
  );
}
