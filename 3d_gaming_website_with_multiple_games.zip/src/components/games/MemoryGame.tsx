import { useState, useEffect } from 'react';
import { useMutation } from 'convex/react';
import { api } from '../../../convex/_generated/api';

interface MemoryGameProps {
  gameId: string;
}

export default function MemoryGame({ gameId }: MemoryGameProps) {
  const [sequence, setSequence] = useState<number[]>([]);
  const [playerSequence, setPlayerSequence] = useState<number[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPlayerTurn, setIsPlayerTurn] = useState(false);
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [gameStarted, setGameStarted] = useState(false);
  const [playerName, setPlayerName] = useState('');
  const [activeButton, setActiveButton] = useState<number | null>(null);
  const saveScore = useMutation(api.games.saveScore);

  const colors = ['#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4', '#ffeaa7', '#dda0dd', '#ff9ff3', '#54a0ff', '#5f27cd'];

  const startGame = () => {
    if (playerName.trim()) {
      setGameStarted(true);
      setScore(0);
      setGameOver(false);
      nextRound();
    }
  };

  const nextRound = () => {
    const newNumber = Math.floor(Math.random() * 9);
    const newSequence = [...sequence, newNumber];
    setSequence(newSequence);
    setPlayerSequence([]);
    setIsPlayerTurn(false);
    playSequence(newSequence);
  };

  const playSequence = async (seq: number[]) => {
    setIsPlaying(true);
    for (let i = 0; i < seq.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 600));
      setActiveButton(seq[i]);
      await new Promise(resolve => setTimeout(resolve, 400));
      setActiveButton(null);
    }
    setIsPlaying(false);
    setIsPlayerTurn(true);
  };

  const handleButtonClick = async (buttonIndex: number) => {
    if (!isPlayerTurn || isPlaying) return;

    const newPlayerSequence = [...playerSequence, buttonIndex];
    setPlayerSequence(newPlayerSequence);

    if (newPlayerSequence[newPlayerSequence.length - 1] !== sequence[newPlayerSequence.length - 1]) {
      // Wrong button
      setGameOver(true);
      setIsPlayerTurn(false);
      if (score > 0 && playerName.trim()) {
        try {
          await saveScore({
            gameId: gameId as any,
            score,
            playerName: playerName.trim(),
            gameData: { level: sequence.length },
          });
        } catch (error) {
          console.error('Failed to save score:', error);
        }
      }
      return;
    }

    if (newPlayerSequence.length === sequence.length) {
      // Completed sequence
      setScore(prev => prev + sequence.length * 10);
      setIsPlayerTurn(false);
      setTimeout(() => {
        nextRound();
      }, 1000);
    }
  };

  const resetGame = () => {
    setSequence([]);
    setPlayerSequence([]);
    setIsPlaying(false);
    setIsPlayerTurn(false);
    setScore(0);
    setGameOver(false);
    setGameStarted(false);
    setActiveButton(null);
  };

  if (!gameStarted) {
    return (
      <div className="flex flex-col items-center space-y-6 bg-black/50 backdrop-blur-md rounded-2xl p-8 border border-white/20">
        <h2 className="text-3xl font-bold text-white mb-4">Memory Matrix</h2>
        <div className="space-y-4">
          <input
            type="text"
            placeholder="Enter your name"
            value={playerName}
            onChange={(e) => setPlayerName(e.target.value)}
            className="px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:border-cyan-400"
          />
          <button
            onClick={startGame}
            disabled={!playerName.trim()}
            className="w-full px-6 py-3 bg-gradient-to-r from-cyan-500 to-purple-600 rounded-lg text-white font-bold hover:scale-105 transition-transform disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Start Game
          </button>
        </div>
        <div className="text-white/70 text-center">
          <p>Watch the sequence and repeat it</p>
          <p>Each round adds one more color to remember!</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center space-y-6">
      <div className="flex items-center space-x-8 text-white">
        <div className="text-xl">Score: <span className="text-cyan-400 font-bold">{score}</span></div>
        <div className="text-xl">Level: <span className="text-purple-400 font-bold">{sequence.length}</span></div>
        <div className="text-xl">Player: <span className="text-pink-400 font-bold">{playerName}</span></div>
      </div>

      <div className="text-white text-center">
        {isPlaying && <p className="text-xl">Watch the sequence...</p>}
        {isPlayerTurn && <p className="text-xl">Your turn! Repeat the sequence</p>}
        {!isPlaying && !isPlayerTurn && !gameOver && <p className="text-xl">Get ready...</p>}
      </div>

      <div className="grid grid-cols-3 gap-4 p-8 bg-black/30 rounded-2xl border border-white/20">
        {colors.map((color, index) => (
          <button
            key={index}
            onClick={() => handleButtonClick(index)}
            disabled={!isPlayerTurn}
            className={`w-20 h-20 rounded-lg transition-all duration-200 transform hover:scale-110 ${
              activeButton === index ? 'scale-125 shadow-2xl' : ''
            } ${!isPlayerTurn ? 'cursor-not-allowed opacity-50' : 'cursor-pointer'}`}
            style={{
              backgroundColor: color,
              boxShadow: activeButton === index ? `0 0 30px ${color}` : `0 4px 15px ${color}40`,
            }}
          />
        ))}
      </div>

      {gameOver && (
        <div className="bg-black/80 backdrop-blur-md rounded-2xl p-8 border border-red-500/50 text-center">
          <h3 className="text-3xl font-bold text-white mb-4">Game Over!</h3>
          <p className="text-xl text-cyan-400 mb-2">Final Score: {score}</p>
          <p className="text-lg text-purple-400 mb-6">You reached level {sequence.length}</p>
          <button
            onClick={resetGame}
            className="px-6 py-3 bg-gradient-to-r from-purple-600 to-cyan-600 rounded-lg text-white font-bold hover:scale-105 transition-transform"
          >
            Play Again
          </button>
        </div>
      )}
    </div>
  );
}
