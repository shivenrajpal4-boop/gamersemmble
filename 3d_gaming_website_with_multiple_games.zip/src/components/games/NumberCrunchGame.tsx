import { useState, useEffect, useCallback } from 'react';
import { useMutation } from 'convex/react';
import { api } from '../../../convex/_generated/api';

interface NumberCrunchGameProps {
  gameId: string;
}

type Question = {
  question: string;
  answer: number;
  options: number[];
};

export default function NumberCrunchGame({ gameId }: NumberCrunchGameProps) {
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(60);
  const [gameStarted, setGameStarted] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [playerName, setPlayerName] = useState('');
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [streak, setStreak] = useState(0);
  const [level, setLevel] = useState(1);
  const [questionsAnswered, setQuestionsAnswered] = useState(0);
  const saveScore = useMutation(api.games.saveScore);

  const generateQuestion = useCallback(() => {
    const operations = ['+', '-', '*'];
    const operation = operations[Math.floor(Math.random() * operations.length)];
    
    let num1: number, num2: number, answer: number, question: string;
    
    // Adjust difficulty based on level
    const maxNum = Math.min(10 + level * 5, 50);
    
    switch (operation) {
      case '+':
        num1 = Math.floor(Math.random() * maxNum) + 1;
        num2 = Math.floor(Math.random() * maxNum) + 1;
        answer = num1 + num2;
        question = `${num1} + ${num2}`;
        break;
      case '-':
        num1 = Math.floor(Math.random() * maxNum) + 10;
        num2 = Math.floor(Math.random() * (num1 - 1)) + 1;
        answer = num1 - num2;
        question = `${num1} - ${num2}`;
        break;
      case '*':
        num1 = Math.floor(Math.random() * Math.min(12, level + 5)) + 1;
        num2 = Math.floor(Math.random() * Math.min(12, level + 5)) + 1;
        answer = num1 * num2;
        question = `${num1} × ${num2}`;
        break;
      default:
        num1 = 1;
        num2 = 1;
        answer = 2;
        question = '1 + 1';
    }
    
    // Generate wrong options
    const options = [answer];
    while (options.length < 4) {
      let wrongAnswer: number;
      if (operation === '*') {
        wrongAnswer = answer + Math.floor(Math.random() * 20) - 10;
      } else {
        wrongAnswer = answer + Math.floor(Math.random() * 10) - 5;
      }
      
      if (wrongAnswer > 0 && !options.includes(wrongAnswer)) {
        options.push(wrongAnswer);
      }
    }
    
    // Shuffle options
    options.sort(() => Math.random() - 0.5);
    
    setCurrentQuestion({ question, answer, options });
  }, [level]);

  const startGame = () => {
    if (playerName.trim()) {
      setGameStarted(true);
      setScore(0);
      setTimeLeft(60);
      setGameOver(false);
      setStreak(0);
      setLevel(1);
      setQuestionsAnswered(0);
      generateQuestion();
    }
  };

  const handleAnswer = async (selectedAnswer: number) => {
    if (!gameStarted || gameOver || !currentQuestion) return;

    setQuestionsAnswered(prev => prev + 1);

    if (selectedAnswer === currentQuestion.answer) {
      const points = 10 + streak * 2 + level * 5;
      setScore(prev => prev + points);
      setStreak(prev => prev + 1);
      
      // Level up every 10 correct answers
      if ((questionsAnswered + 1) % 10 === 0) {
        setLevel(prev => prev + 1);
      }
    } else {
      setStreak(0);
      // Small penalty for wrong answer
      setScore(prev => Math.max(0, prev - 5));
    }

    generateQuestion();
  };

  const endGame = useCallback(async () => {
    setGameOver(true);
    setGameStarted(false);
    
    if (score > 0 && playerName.trim()) {
      try {
        await saveScore({
          gameId: gameId as any,
          score,
          playerName: playerName.trim(),
          gameData: { level, time: 60 - timeLeft },
        });
      } catch (error) {
        console.error('Failed to save score:', error);
      }
    }
  }, [score, playerName, timeLeft, level, saveScore, gameId]);

  useEffect(() => {
    if (!gameStarted || gameOver) return;

    if (timeLeft <= 0) {
      endGame();
      return;
    }

    const timer = setTimeout(() => {
      setTimeLeft(prev => prev - 1);
    }, 1000);

    return () => clearTimeout(timer);
  }, [timeLeft, gameStarted, gameOver, endGame]);

  const resetGame = () => {
    setGameStarted(false);
    setGameOver(false);
    setScore(0);
    setTimeLeft(60);
    setStreak(0);
    setLevel(1);
    setQuestionsAnswered(0);
  };

  if (!gameStarted && !gameOver) {
    return (
      <div className="flex flex-col items-center space-y-6 bg-black/50 backdrop-blur-md rounded-2xl p-8 border border-white/20">
        <h2 className="text-3xl font-bold text-white mb-4">Number Crunch</h2>
        <div className="space-y-4">
          <input
            type="text"
            placeholder="Enter your name"
            value={playerName}
            onChange={(e) => setPlayerName(e.target.value)}
            className="px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:border-cyan-400"
          />
          <button
            onClick={startGame}
            disabled={!playerName.trim()}
            className="