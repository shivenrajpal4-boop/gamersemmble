import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useState } from "react";
import SnakeGame from "./games/SnakeGame";
import MemoryGame from "./games/MemoryGame";
import TetrisGame from "./games/TetrisGame";
import ColorRushGame from "./games/ColorRushGame";
import MazeGame from "./games/MazeGame";
import NumberCrunchGame from "./games/NumberCrunchGame";

interface GamePageProps {
  gameId: string;
  onBack: () => void;
}

export default function GamePage({ gameId, onBack }: GamePageProps) {
  const game = useQuery(api.games.getGame, { gameId: gameId as any });
  const leaderboard = useQuery(api.games.getLeaderboard, { gameId: gameId as any, limit: 5 });
  const [showLeaderboard, setShowLeaderboard] = useState(false);

  if (!game) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-400"></div>
      </div>
    );
  }

  const renderGame = () => {
    switch (game.name) {
      case "Snake 3D":
        return <SnakeGame gameId={gameId} />;
      case "Memory Matrix":
        return <MemoryGame gameId={gameId} />;
      case "Cosmic Tetris":
        return <TetrisGame gameId={gameId} />;
      case "Color Rush":
        return <ColorRushGame gameId={gameId} />;
      case "Maze Runner 3D":
        return <MazeGame gameId={gameId} />;
      case "Number Crunch":
        return <NumberCrunchGame gameId={gameId} />;
      default:
        return (
          <div className="text-center text-white">
            <h2 className="text-2xl mb-4">Game Coming Soon!</h2>
            <p>This game is under development.</p>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen relative">
      <div className="absolute top-4 left-4 z-50">
        <button
          onClick={onBack}
          className="px-4 py-2 bg-black/50 backdrop-blur-md rounded-lg text-white hover:bg-black/70 transition-colors border border-white/20"
        >
          ← Back to Games
        </button>
      </div>

      <div className="absolute top-4 right-4 z-50">
        <button
          onClick={() => setShowLeaderboard(!showLeaderboard)}
          className="px-4 py-2 bg-black/50 backdrop-blur-md rounded-lg text-white hover:bg-black/70 transition-colors border border-white/20"
        >
          🏆 Leaderboard
        </button>
      </div>

      {showLeaderboard && (
        <div className="absolute top-16 right-4 z-50 bg-black/80 backdrop-blur-md rounded-lg p-4 border border-white/20 min-w-64">
          <h3 className="text-white font-bold mb-3">Top Scores</h3>
          {leaderboard && leaderboard.length > 0 ? (
            <div className="space-y-2">
              {leaderboard.map((score, index) => (
                <div key={score._id} className="flex justify-between text-sm">
                  <span className="text-white/80">
                    {index + 1}. {score.playerName}
                  </span>
                  <span className="text-cyan-400 font-bold">{score.score}</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-white/60 text-sm">No scores yet!</p>
          )}
        </div>
      )}

      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">{game.name}</h1>
          <p className="text-white/70">{game.description}</p>
        </div>

        <div className="flex justify-center">
          {renderGame()}
        </div>
      </div>
    </div>
  );
}
