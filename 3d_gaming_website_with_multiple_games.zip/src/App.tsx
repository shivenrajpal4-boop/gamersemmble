import { Authenticated, Unauthenticated, useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { useState, useEffect } from "react";
import LandingPage from "./components/LandingPage";
import HomePage from "./components/HomePage";
import GamePage from "./components/GamePage";

export default function App() {
  const [currentPage, setCurrentPage] = useState<'landing' | 'home' | 'game'>('landing');
  const [selectedGame, setSelectedGame] = useState<string | null>(null);
  const loggedInUser = useQuery(api.auth.loggedInUser);
  const initializeGames = useMutation(api.games.initializeGames);

  useEffect(() => {
    initializeGames();
  }, [initializeGames]);

  const handleEnterSite = () => {
    setCurrentPage('home');
  };

  const handlePlayGame = (gameId: string) => {
    setSelectedGame(gameId);
    setCurrentPage('game');
  };

  const handleBackToHome = () => {
    setCurrentPage('home');
    setSelectedGame(null);
  };

  if (currentPage === 'landing') {
    return <LandingPage onEnter={handleEnterSite} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <header className="sticky top-0 z-50 bg-black/20 backdrop-blur-md border-b border-white/10">
        <div className="container mx-auto px-4 h-16 flex justify-between items-center">
          <div 
            className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent cursor-pointer"
            onClick={handleBackToHome}
          >
            GameVerse 3D
          </div>
          <div className="flex items-center gap-4">
            <Authenticated>
              <span className="text-white/80">
                Welcome, {loggedInUser?.email?.split('@')[0] ?? "Player"}!
              </span>
            </Authenticated>
            <SignOutButton />
          </div>
        </div>
      </header>

      <main className="flex-1">
        {currentPage === 'home' && (
          <HomePage onPlayGame={handlePlayGame} />
        )}
        {currentPage === 'game' && selectedGame && (
          <GamePage gameId={selectedGame} onBack={handleBackToHome} />
        )}
      </main>

      <Unauthenticated>
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
            <h2 className="text-2xl font-bold text-white mb-4 text-center">
              Sign in to save your scores!
            </h2>
            <SignInForm />
          </div>
        </div>
      </Unauthenticated>

      <Toaster />
    </div>
  );
}
